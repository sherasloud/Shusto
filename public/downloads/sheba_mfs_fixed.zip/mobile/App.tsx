import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { ActivityIndicator, View } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import * as ScreenOrientation from 'expo-screen-orientation';
import Ionicons from 'react-native-vector-icons/Ionicons';

import LoginScreen from './src/screens/auth/LoginScreen';
import OTPScreen from './src/screens/auth/OTPScreen';
import PINLockScreen from './src/screens/auth/PINLockScreen';
import HomeScreen from './src/screens/home/HomeScreen';
import VerificationScreen from './src/screens/verification/VerificationScreen';
import AddMoneyScreen from './src/screens/money/AddMoneyScreen';
import SendMoneyScreen from './src/screens/money/SendMoneyScreen';
import ScanQRScreen from './src/screens/money/ScanQRScreen';
import SettingsScreen from './src/screens/settings/SettingsScreen';
import TransactionHistoryScreen from './src/screens/history/TransactionHistoryScreen';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

const AuthStack = () => (
  <Stack.Navigator
    screenOptions={{
      headerShown: false,
    }}
  >
    <Stack.Screen name="Login" component={LoginScreen} />
    <Stack.Screen name="OTP" component={OTPScreen} />
    <Stack.Screen name="PINSetup" component={PINLockScreen} />
  </Stack.Navigator>
);

const PINStack = () => (
  <Stack.Navigator
    screenOptions={{
      headerShown: false,
    }}
  >
    <Stack.Screen name="PINLock" component={PINLockScreen} />
  </Stack.Navigator>
);

const AppTabs = () => (
  <Tab.Navigator
    screenOptions={({ route }) => ({
      headerShown: true,
      headerStyle: {
        backgroundColor: '#1F2937',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
      tabBarActiveTintColor: '#3B82F6',
      tabBarInactiveTintColor: '#9CA3AF',
      tabBarStyle: {
        backgroundColor: '#1F2937',
        borderTopColor: '#374151',
      },
      tabBarIcon: ({ focused, color, size }) => {
        let iconName = 'ellipse';
        if (route.name === 'Home') {
          iconName = focused ? 'home' : 'home-outline';
        } else if (route.name === 'AddMoney') {
          iconName = focused ? 'wallet' : 'wallet-outline';
        } else if (route.name === 'SendMoney') {
          iconName = focused ? 'send' : 'send-outline';
        } else if (route.name === 'ScanQR') {
          iconName = focused ? 'qr-code' : 'qr-code-outline';
        } else if (route.name === 'History') {
          iconName = focused ? 'receipt' : 'receipt-outline';
        } else if (route.name === 'Settings') {
          iconName = focused ? 'settings' : 'settings-outline';
        }
        return <Ionicons name={iconName} size={size} color={color} />;
      },
    })}
  >
    <Tab.Screen
      name="Home"
      component={HomeScreen}
      options={{ title: 'হোম' }}
    />
    <Tab.Screen
      name="AddMoney"
      component={AddMoneyScreen}
      options={{ title: 'টাকা যোগ' }}
    />
    <Tab.Screen
      name="SendMoney"
      component={SendMoneyScreen}
      options={{ title: 'টাকা পাঠান' }}
    />
    <Tab.Screen
      name="ScanQR"
      component={ScanQRScreen}
      options={{ title: 'QR স্ক্যান' }}
    />
    <Tab.Screen
      name="History"
      component={TransactionHistoryScreen}
      options={{ title: 'স্টেটমেন্ট' }}
    />
    <Tab.Screen
      name="Settings"
      component={SettingsScreen}
      options={{ title: 'সেটিংস' }}
    />
  </Tab.Navigator>
);

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isPINSet, setIsPINSet] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP).catch((error) => {
      console.warn('[Sheba MFS] Unable to lock portrait orientation:', error);
    });
    checkAuthStatus();
  }, []);

  const checkAuthStatus = async () => {
    try {
      const token = await SecureStore.getItemAsync('authToken');
      const pinSet = await SecureStore.getItemAsync('pinSet');
      setIsLoggedIn(!!token);
      setIsPINSet(!!pinSet);
    } catch (error) {
      console.error('[Sheba MFS] Error checking auth status:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#111827' }}>
        <ActivityIndicator size="large" color="#3B82F6" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      {!isLoggedIn ? (
        <AuthStack />
      ) : isPINSet ? (
        <PINStack />
      ) : (
        <AppTabs />
      )}
    </NavigationContainer>
  );
}
