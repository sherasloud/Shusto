#!/bin/bash
# Sheba MFS - Play Store AAB Builder
set -e

echo "==========================================="
echo "   Sheba MFS - Play Store AAB Builder"
echo "==========================================="

if [ ! -d "node_modules" ]; then
  echo "node_modules not found. Running npm install first..."
  npm install
fi

NODE_BIN=$(which node || true)
if [ -n "$NODE_BIN" ]; then
  export NODE_BINARY="$NODE_BIN"
fi

cd android || exit 1
chmod +x gradlew

echo "Cleaning and Building Release Android App Bundle (.aab)..."
./gradlew bundleRelease

echo ""
echo "==========================================="
echo "  BUILD COMPLETED SUCCESSFULLY! 🚀"
echo "  Play Store ready .aab file:"
echo "  android/app/build/outputs/bundle/release/app-release.aab"
echo "==========================================="
