#!/bin/bash
# Sheba MFS - Auto Fix settings.gradle & Build .AAB
set -e

echo "====================================================="
echo "  Sheba MFS: Fixing settings.gradle & Building .AAB"
echo "====================================================="

# Step 1: Install npm dependencies if missing
if [ ! -d "node_modules" ]; then
  echo "📦 Installing npm dependencies (needed for React Native Gradle Plugin)..."
  npm install
else
  echo "✔ node_modules folder is ready."
fi

# Step 2: Build Release App Bundle (.aab)
cd android || exit 1
chmod +x gradlew

echo "🚀 Building Google Play Store Release App Bundle (.aab)..."
./gradlew bundleRelease

echo ""
echo "====================================================="
echo "🎉 SUCCESS! Your Google Play Store .AAB is ready at:"
echo "mobile/android/app/build/outputs/bundle/release/app-release.aab"
echo "====================================================="
