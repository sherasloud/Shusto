#!/bin/bash
# Sheba MFS - macOS Quick Fix & Setup Script
set -e

echo "=================================================="
echo "  Sheba MFS - Auto Fix & Setup for Mac / Android Studio"
echo "=================================================="

# 1. Step 1: Install npm dependencies
echo "[Step 1/3] Installing NPM dependencies..."
npm install

# 2. Step 2: Check Node executable
echo "[Step 2/3] Checking Node.js binary location..."
NODE_BIN=$(which node || true)

if [ -z "$NODE_BIN" ]; then
  echo "Error: Node.js is not found in your terminal! Please install Node.js (via brew install node or nodejs.org)."
  exit 1
fi

echo "Found Node at: $NODE_BIN"

# Create standard symlink in /usr/local/bin if needed (for macOS GUI apps)
if [ ! -f /usr/local/bin/node ]; then
  echo "Creating symlink /usr/local/bin/node for macOS GUI Android Studio..."
  sudo ln -sf "$NODE_BIN" /usr/local/bin/node 2>/dev/null || echo "(Tip: If Android Studio GUI still cannot find node, run: sudo ln -sf $NODE_BIN /usr/local/bin/node)"
fi

echo "[Step 3/3] Setting Gradle permissions..."
chmod +x android/gradlew || true

echo ""
echo "=================================================="
echo "  SETUP SUCCESSFUL! 🎉"
echo "=================================================="
echo "To build or sync:"
echo "1. In Android Studio: Click 'File' -> 'Sync Project with Gradle Files' (Elephant icon)"
echo "2. OR build directly from terminal (No Android Studio required!):"
echo "   ./build-aab.sh"
echo "   (Generates mobile/android/app/build/outputs/bundle/release/app-release.aab)"
echo "=================================================="
