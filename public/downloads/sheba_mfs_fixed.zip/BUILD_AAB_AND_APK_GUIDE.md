# Sheba MFS (সেবা ওয়ালেট) - Play Store .AAB এবং .APK তৈরি করার সম্পূর্ণ গাইড

আপনার প্রজেক্টের সব ফাইল এবং Android কনফিগারেশন সফলভাবে ফিক্স করা হয়েছে:
- `mobile/App.tsx`-এর সব মিসিং পাথ ঠিক করা হয়েছে।
- মিসিং `SettingsScreen.tsx` এবং `TransactionHistoryScreen.tsx` তৈরি করে যুক্ত করা হয়েছে।
- `SIMDetector` সম্পূর্ণ রিমুভ করে Clean Architecture সেট করা হয়েছে।
- `mobile/android` ফোল্ডারে Play Store-এর জন্য Release .AAB এবং .APK কনফিগারেশন প্রস্তুত।

---

## 🚀 অপশন ১: Android Studio দিয়ে এক ক্লিকে .AAB তৈরি (সবচেয়ে সহজ)
১. আপনার কম্পিউটারে **Android Studio** খুলুন।
২. **File -> Open** এ গিয়ে এই জিপটি আনজিপ করা ফোল্ডারের ভেতর থেকে শুধুমাত্র **`mobile/android`** ফোল্ডারটি ওপেন করুন (পুরো প্রজেক্ট নয়, শুধুমাত্র `mobile/android`)।
৩. Android Studio স্বয়ংক্রিয়ভাবে Gradle Sync সম্পন্ন করবে (নিচে ডানপাশে 'BUILD SUCCESSFUL' দেখাবে)।
৪. উপরের মেনু বার থেকে ক্লিক করুন:
   👉 **Build -> Generate Signed Bundle / APK...**
৫. **Android App Bundle (.aab)** সিলেক্ট করে **Next** দিন।
৬. আপনার কি-স্টোর বেছে নিন (অথবা ডিবাগ কি-স্টোর ব্যবহার করতে চাইলে `mobile/android/app/debug.keystore` সিলেক্ট করতে পারেন; পাসওয়ার্ড: `android`)।
৭. **Destination Folder** সিলেক্ট করে **Release** টিক দিন এবং **Finish** ক্লিক করুন!
৮. কয়েক মিনিটের মধ্যে আপনার **`app-release.aab`** তৈরি হয়ে যাবে, যা সরাসরি Google Play Console-এ আপলোড করতে পারবেন!

---

## ⚡ অপশন ২: টার্মিনাল / কমান্ড লাইন থেকে কমান্ড দিয়ে (Mac / Linux / Windows)
আপনার কম্পিউটারে টার্মিনাল খুলে `mobile/android` ডিরেক্টরিতে যান:

```bash
cd mobile/android
./gradlew bundleRelease
```
*(উইন্ডোজে: `gradlew.bat bundleRelease`)*

বিল্ড সম্পন্ন হলে আপনার `.aab` ফাইলটি এখানে পাবেন:
📁 **`mobile/android/app/build/outputs/bundle/release/app-release.aab`**

### টেস্টিং APK তৈরি করতে চাইলে:
```bash
./gradlew assembleRelease
```
📁 **`mobile/android/app/build/outputs/apk/release/app-release.apk`**

---

## ☁️ অপশন ৩: Expo EAS Cloud বিল্ড
যদি আপনার কম্পিউটারে Android Studio সেটআপ না থাকে, তাহলে Expo ক্লাউড দিয়ে সরাসরি অনলাইনেও বানাতে পারবেন:
```bash
cd mobile
npx eas-cli build --platform android
```
