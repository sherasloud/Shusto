'use client'

import { useState, useEffect } from 'react'
import { DiditSdk } from '@didit-protocol/sdk-web'
import { useRouter } from 'next/navigation'
import { ArrowLeft, ArrowUp, ArrowDown, LogOut, Copy, Check, Upload, User } from 'lucide-react'
import Link from 'next/link'

export default function InboxPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState('transactions')
  const [transactions, setTransactions] = useState([])
  const [notifications, setNotifications] = useState([])
  const [loading, setLoading] = useState(true)
  const [userPhone, setUserPhone] = useState('')
  const [userName, setUserName] = useState('')
  const [isVerified, setIsVerified] = useState(false)
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const [profilePic, setProfilePic] = useState<string | null>(null)
  const [uploadingProfile, setUploadingProfile] = useState(false)
  const [transactionProfilePics, setTransactionProfilePics] = useState<Record<string, string | null>>({})
  const [showNameModal, setShowNameModal] = useState(false)
  const [newName, setNewName] = useState('')

  useEffect(() => {
    const phone = localStorage.getItem('phoneNumber')
    const name = localStorage.getItem('userName') || 'User'
  if (!phone) {
      router.push('/pin')
      return
    }
    setUserPhone(phone)
    setUserName(name)
    setNewName(name)
  fetch(`/api/verification-status?phone=${encodeURIComponent(phone)}`)
    .then((response) => response.ok ? response.json() : null)
    .then((result) => setIsVerified(result?.success === true && result.data?.nidVerified === true))
    .catch(() => setIsVerified(false))
  loadTransactions(phone)
    loadNotifications(phone)
  }, [router])

  const loadNotifications = async (phone: string) => {
    try {
      const trimmedPhone = phone.trim()
      const response = await fetch('/api/get-notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: trimmedPhone }),
      })

      const data = await response.json()
      if (response.ok) {
        setNotifications(data.notifications || [])
      }
    } catch (error) {
      console.error('[v0] Error loading notifications:', error)
    }
  }

  const handleNameChange = () => {
    if (newName.trim()) {
      localStorage.setItem('userName', newName)
      setUserName(newName)
      setShowNameModal(false)
    }
  }

  const loadTransactions = async (phone: string) => {
    try {
      const trimmedPhone = phone.trim()
      console.log('[v0] Inbox: Loading transactions for:', trimmedPhone)
      
      const response = await fetch('/api/get-transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: trimmedPhone }),
      })

      const data = await response.json()
      console.log('[v0] Inbox: API response:', { status: response.status, count: data.transactions?.length })

      if (response.ok) {
        setTransactions(data.transactions || [])
      } else {
        console.error('[v0] Inbox: API error:', data)
      }
    } catch (error) {
      console.error('[v0] Error loading transactions:', error)
    } finally {
      setLoading(false)
    }
  }

  const formatDate = (date: string | Date) => {
    const d = new Date(date)
    const options: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    }
    return d.toLocaleDateString('bn-BD', options)
  }

  const getMonthYear = (date: string | Date) => {
    const d = new Date(date)
    return d.toLocaleDateString('bn-BD', { month: 'long', year: 'numeric' })
  }

  const groupedTransactions = transactions.reduce((acc: any, tx: any) => {
    const monthYear = getMonthYear(tx.createdAt)
    if (!acc[monthYear]) acc[monthYear] = []
    acc[monthYear].push(tx)
    return acc
  }, {})

  // Money goes out if this is the user's transaction
  const isMoneyOut = (tx: any) => tx.phonenumber === userPhone
  // Description contains recipient info
  const otherParty = (tx: any) => tx.description?.split(' ')?.pop() || 'Transaction'

  const handleLogout = () => {
    localStorage.clear()
    router.push('/pin')
  }

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text)
    setCopiedId(id)
    setTimeout(() => setCopiedId(null), 2000)
  }

  const handleProfilePicUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setUploadingProfile(true)
    try {
      const reader = new FileReader()
      reader.onload = (event) => {
        const base64String = event.target?.result as string
        localStorage.setItem(`profilePic_${userPhone}`, base64String)
        setProfilePic(base64String)
        console.log('[v0] Profile pic uploaded successfully')
      }
      reader.readAsDataURL(file)
    } catch (err) {
      console.error('[v0] Error uploading profile pic:', err)
    } finally {
      setUploadingProfile(false)
    }
  }

  useEffect(() => {
    if (userPhone && transactions.length > 0) {
      const savedPic = localStorage.getItem(`profilePic_${userPhone}`)
      if (savedPic) {
        setProfilePic(savedPic)
      }

      // Load profile pics for all transaction users
      const pics: Record<string, string | null> = {}
      transactions.forEach((tx: any) => {
        const otherPhone = tx.type === 'transfer' && tx.toPhone
          ? tx.toPhone
          : tx.type === 'receive'
            ? tx.fromPhone || 'Unknown'
            : tx.toPhone || 'System'
        
        const savedUserPic = localStorage.getItem(`profilePic_${otherPhone}`)
        if (savedUserPic) {
          pics[otherPhone] = savedUserPic
        }
      })
      setTransactionProfilePics(pics)
    }
  }, [userPhone, transactions])

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="flex items-center justify-between bg-white px-5 pb-3 pt-5">
        <button onClick={() => router.push('/')} className="flex h-11 w-11 items-center justify-center text-[#142033]" aria-label="Back">
          <ArrowLeft size={30} strokeWidth={1.8} />
        </button>
        <img src="/images/inbox-header-logo.png" alt="সেবা" className="h-10 w-[150px] object-contain" />
        <div className="w-11" />
      </header>

      {/* Tabs */}
      <div className="flex gap-0 bg-white sticky top-0 z-10">
        <button
          onClick={() => setActiveTab('transactions')}
          className={`flex-1 py-3 px-4 font-medium transition-colors ${
            activeTab === 'transactions'
              ? 'text-[#1FBFFF]'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          Transactions
        </button>
        <button
          onClick={() => setActiveTab('notifications')}
          className={`flex-1 py-3 px-4 font-medium transition-colors ${
            activeTab === 'notifications'
              ? 'text-[#1FBFFF]'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          Notifications
        </button>
        <button
          onClick={() => setActiveTab('account')}
          className={`flex-1 py-3 px-4 font-medium transition-colors ${
            activeTab === 'account'
              ? 'text-[#1FBFFF]'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          Settings
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        {/* Transactions Tab */}
        {activeTab === 'transactions' && (
          <div className="p-0">
            {loading ? (
              <div className="flex items-center justify-center h-40">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#1FBFFF]"></div>
              </div>
            ) : transactions.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-40">
                <p className="text-gray-500 text-center">কোন লেনদেন নেই</p>
              </div>
            ) : (
              <div className="space-y-0">
                {transactions.map((tx: any, index: number) => {
                  const isReceived = tx.description?.includes('Received from')
                  const otherPhone = tx.description?.split(' ')?.pop() || tx.phonenumber
                  const colors = ['bg-purple-500', 'bg-green-500', 'bg-pink-500', 'bg-red-500', 'bg-orange-500']
                  const hash = (otherPhone?.charCodeAt(0) || 0) % colors.length
                  const bgColor = colors[hash]
                  
                  const userProfilePic = transactionProfilePics[otherPhone]
                  const displayChar = otherPhone ? otherPhone.charAt(0).toUpperCase() : null

                  return (
                    <div
                      key={tx.id}
                      className="flex items-center gap-4 p-2 bg-white mx-2 my-0 hover:bg-gray-50 transition"
                    >
                      <div className={`w-12 h-12 rounded-full ${bgColor} flex items-center justify-center text-white font-bold text-sm flex-shrink-0 overflow-hidden`}>
                        {userProfilePic ? (
                          <img src={userProfilePic} alt={otherPhone || 'Profile'} className="w-full h-full object-cover" />
  ) : displayChar ? (
  displayChar
  ) : (
  <User size={22} strokeWidth={1.8} aria-hidden="true" />
  )}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-gray-900">
                          {isReceived ? 'Received' : tx.type === 'transfer' ? 'Send Money' : tx.type === 'cashout' ? 'Cashout' : 'Payment'}
                        </p>
                        <p className="text-sm text-gray-600">
                          {isReceived ? 'From' : 'To'} {otherPhone}
                        </p>
                        <p className="text-xs text-gray-500 mt-1">
                          {new Date(tx.createdAt).toLocaleDateString('en-BD')} {new Date(tx.createdAt).toLocaleTimeString('en-BD', {
                            hour: '2-digit',
                            minute: '2-digit',
                            second: '2-digit',
                            hour12: true
                          })}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <p className="text-xs text-blue-600 font-medium">
                            ID: {tx.id.replace('_rcv', '')}
                          </p>
                          <button
                            onClick={() => copyToClipboard(tx.id.replace('_rcv', ''), tx.id)}
                            className="p-1 hover:bg-blue-50 rounded transition"
                            title="Copy Transaction ID"
                          >
                            {copiedId === tx.id ? (
                              <Check size={14} className="text-green-600" />
                            ) : (
                              <Copy size={14} className="text-blue-600 hover:text-blue-800" />
                            )}
                          </button>
                        </div>
                      </div>
                      
                      <div className="text-right flex-shrink-0">
                        <p className={`font-bold text-lg ${isReceived ? 'text-blue-600' : 'text-red-600'}`}>
                          {isReceived ? '+' : '-'}৳{Number(tx.amount).toLocaleString('bn-BD')}
                        </p>
                        {tx.description?.includes('Fee:') && (
                          <p className="text-xs text-gray-600 mt-1">
                            {tx.description.split(' - ')[1]}
                          </p>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        )}

        {/* Notifications Tab */}
        {activeTab === 'notifications' && (
          <div className="p-0">
            {notifications.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-40">
                <p className="text-gray-500 text-center">কোন বিজ্ঞ��্তি নেই</p>
              </div>
            ) : (
              <div className="divide-y divide-gray-200">
                {notifications.map((notif: any) => (
                  <div
                    key={notif.id}
                    className={`p-4 flex items-start gap-3 ${notif.isRead ? 'bg-gray-50' : 'bg-blue-50'}`}
                  >
                    <div className={`w-3 h-3 rounded-full mt-2 flex-shrink-0 ${notif.isRead ? 'bg-gray-300' : 'bg-blue-500'}`}></div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900">{notif.message}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {new Date(notif.createdAt).toLocaleDateString('bn-BD', {
                          day: 'numeric',
                          month: '2-digit',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                          hour12: true,
                        })}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Settings Tab */}
        {activeTab === 'account' && (
          <div className="min-h-full bg-white px-6 pb-16 pt-12 text-black">
            <div className="flex flex-col items-center">
              <label className="relative cursor-pointer">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleProfilePicUpload}
                  disabled={uploadingProfile}
                  className="hidden"
                />
                <div className="flex h-52 w-52 items-center justify-center overflow-hidden rounded-full bg-[#b9ddf8]">
                  {profilePic ? (
                    <img src={profilePic} alt="Profile" className="h-full w-full object-cover" />
                  ) : (
                    <User size={92} strokeWidth={1.2} className="text-white" />
                  )}
                </div>
              </label>

              <button
                type="button"
                onClick={() => {
                  if (!isVerified) void DiditSdk.shared.startVerification({ url: "https://verify.didit.me/u/-nz59ozcQIevHqyp-PGeLA", configuration: { embedded: false, showCloseButton: true, defaultDocumentCamera: "back", defaultLivenessCamera: "front" } })
                }}
                disabled={isVerified}
                className={`mt-6 flex items-center gap-2 text-xl font-normal ${isVerified ? "cursor-default text-[#1FBFFF]" : "text-[#1FBFFF]"}`}
              >
                {isVerified ? <><Check size={22} strokeWidth={2.5} aria-hidden="true" />Verified</> : "Verify your account"}
              </button>

              <div className="mt-12 flex w-full max-w-md flex-col gap-8 text-2xl font-normal leading-normal">
                <button onClick={() => setShowNameModal(true)} className="flex w-full items-center justify-between text-left">
                  <span>Name</span>
                  <span className="max-w-[60%] truncate text-right">{userName || "ShebaUser"}</span>
                </button>


                <button onClick={() => setShowNameModal(true)} className="flex w-full items-center justify-between text-left">
                  <span>Account</span>
                  <span className="text-right">Change</span>
                </button>

                <button type="button" className="flex w-full items-center justify-between text-left">
                  <span>Language</span>
                  <span className="whitespace-nowrap text-right">বাংলা</span>
                </button>

                <button type="button" className="flex w-full items-center justify-between text-left">
                  <span>PIN</span>
                  <span className="text-right">Change PIN</span>
                </button>

                <button onClick={handleLogout} className="flex w-full items-center justify-between text-left">
                  <span>Account</span>
                  <span className="text-right">Logout</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Name Change Modal */}
      {showNameModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-sm">
            <h2 className="text-lg font-bold mb-4 text-gray-900">নাম পরিবর্তন করুন</h2>
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="নতুন নাম লিখুন"
              className="w-full p-3 border border-gray-300 rounded-lg mb-4"
              autoFocus
            />
            <div className="flex gap-3">
              <button
                onClick={handleNameChange}
                className="flex-1 bg-[#29a9eb] text-white py-2 rounded-lg font-semibold hover:bg-blue-600 transition"
              >
                সংরক্ষণ করুন
              </button>
              <button
                onClick={() => setShowNameModal(false)}
                className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg font-semibold hover:bg-gray-400 transition"
              >
                বাতিল করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
